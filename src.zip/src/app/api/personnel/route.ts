import { NextRequest, NextResponse } from 'next/server'
import { getSession } from '@/lib/auth'
import { getPersons, createPerson } from '@/modules/personnel'
import { PERMISSIONS, hasAnyRole } from '@/lib/permissions'

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session) {
    return NextResponse.json({ message: 'Unauthorised' }, { status: 401 })
  }

  const { searchParams } = new URL(req.url)

  // Personnel listing is no longer role-scoped — any authenticated user gets
  // the full list, filtered only by the explicit query params below.
  const isActiveParam = searchParams.get('isActive')
  const isActive =
    isActiveParam === 'all'   ? undefined
    : isActiveParam === 'false' ? false
    : true

  const persons = await getPersons({
    departmentId: searchParams.get('departmentId') ?? undefined,
    unitId:       searchParams.get('unitId')        ?? undefined,
    sectionId:    searchParams.get('sectionId')     ?? undefined,
    role:         searchParams.get('role')          ?? undefined,
    isActive,
    search:       searchParams.get('search')        ?? undefined,
  })

  return NextResponse.json({ persons })
}

export async function POST(req: NextRequest) {
  const session = await getSession()

  if (!session) {
    return NextResponse.json({ message: 'Unauthorised' }, { status: 401 })
  }

  if (!hasAnyRole(session.user, PERMISSIONS.MANAGE_USERS)) {
    return NextResponse.json({ message: 'Forbidden' }, { status: 403 })
  }

  const body = await req.json()
  const { justification, password, ...input } = body

  if (!justification) {
    return NextResponse.json(
      { message: 'Justification is required' },
      { status: 400 }
    )
  }
  if (!password) {
    return NextResponse.json(
      { message: 'Password is required' },
      { status: 400 }
    )
  }

  try {
    const result = await createPerson(input, justification, session.user.id, password)
    return NextResponse.json(result, { status: 201 })
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Failed to create person'
    return NextResponse.json({ message }, { status: 400 })
  }
}
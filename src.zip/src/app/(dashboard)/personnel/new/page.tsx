import { getSession } from '@/lib/auth'
import { redirect } from 'next/navigation'
import { getDepartmentsUnitsAndSections } from '@/modules/personnel'
import { CreatePersonForm } from '@/components/personnel/CreatePersonForm'
import { PERMISSIONS, hasAnyRole } from '@/lib/permissions'

export default async function NewPersonPage() {
  const session = await getSession()
  if (!session) redirect('/login')

  if (!hasAnyRole(session.user, PERMISSIONS.MANAGE_USERS)) redirect('/unauthorised')

  const departments = await getDepartmentsUnitsAndSections()

  return (
    <div className="min-h-screen p-6" style={{ background: '#f4f6f8' }}>
      <div className="max-w-2xl mx-auto">
        <div className="mb-6">
          <a
            href="/personnel"
            className="text-sm flex items-center gap-1 mb-4"
            style={{ color: '#2d6a4f' }}
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M19 12H5M12 19l-7-7 7-7"/>
            </svg>
            Back to manage users
          </a>
          <h1 className="text-2xl font-bold text-gray-900">Create user</h1>
          <p className="text-sm text-gray-500 mt-1">
            A temporary password will be generated and emailed to the person.
          </p>
        </div>

        <CreatePersonForm departments={departments} />
      </div>
    </div>
  )
}
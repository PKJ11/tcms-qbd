import { getSession } from '@/lib/auth'
import { redirect }   from 'next/navigation'
import { prisma }     from '@/lib/prisma'
import { AssessmentsView } from '@/components/assessments/AssessmentsView'
import { PERMISSIONS, hasAnyRole } from '@/lib/permissions'

export default async function AssessmentsPage({
  searchParams,
}: {
  searchParams: { topicId?: string }
}) {
  const session = await getSession()
  if (!session) redirect('/login')

  const canManage = hasAnyRole(session.user, PERMISSIONS.AUTHOR_CONTENT)
  if (!canManage) redirect('/assignments')

  // If filtering by topic, fetch the topic name for display
  let filteredTopic: { id: string; name: string } | null = null
  if (searchParams.topicId) {
    filteredTopic = await prisma.trainingTopic.findUnique({
      where:  { id: searchParams.topicId },
      select: { id: true, name: true },
    })
  }

  return (
    <div className="min-h-screen p-6" style={{ background: '#f4f6f8' }}>
      <div className="max-w-7xl mx-auto">

        <div className="flex items-start justify-between mb-6">
          <div>
            {filteredTopic && (
              <a
                href={`/topics/${filteredTopic.id}`}
                className="text-xs flex items-center gap-1 mb-2"
                style={{ color: '#2d6a4f' }}
              >
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M19 12H5M12 19l-7-7 7-7"/>
                </svg>
                Back to topic
              </a>
            )}
            <h1 className="text-2xl font-bold text-gray-900">
              {filteredTopic ? `Assessments — ${filteredTopic.name}` : 'Assessments'}
            </h1>
            <p className="text-sm text-gray-500 mt-1">
              {filteredTopic
                ? 'Showing assessment questions filtered to this topic only.'
                : 'Manage questions and review attempt history. URS-ASM-001 to 006.'}
            </p>
          </div>
          <a
            href={
              filteredTopic
                ? `/assessments/banks/new?topicId=${filteredTopic.id}`
                : '/assessments/banks/new'
            }
            className="px-4 py-2 rounded-lg text-sm font-medium text-white flex items-center gap-2"
            style={{ background: '#2d6a4f' }}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="12" y1="5" x2="12" y2="19"/>
              <line x1="5" y1="12" x2="19" y2="12"/>
            </svg>
            Add questions
          </a>
        </div>

        <AssessmentsView topicId={searchParams.topicId} />
      </div>
    </div>
  )
}

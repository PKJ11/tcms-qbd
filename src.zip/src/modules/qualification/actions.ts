'use server'

import { prisma }        from '@/lib/prisma'
import { logAuditEvent } from '@/modules/audit-trail'
import { uploadFile, getSignedFileUrl } from '@/lib/storage'
import {
  createTechniqueSchema,
  createQualificationSchema,
} from './schema'
import type {
  CreateTechniqueInput,
  CreateQualificationInput,
} from './types'
import { canManageQualifications, canSignQcStep, canSignQaStep } from '@/lib/permissions'
import { verifyUserPassword } from '@/lib/auth'

// ── Shared selects ────────────────────────────────────────────────

const TECHNIQUE_SELECT = {
  id:       true,
  name:     true,
  code:     true,
  type:     true,
  isActive: true,
  department: {
    select: {
      id:   true,
      name: true,
      
    },
  },
  _count: { select: { qualifications: true } },
} as const

const QUALIFICATION_SELECT = {
  id:          true,
  status:      true,
  outcome:     true,
  performedOn: true,
  initiatedAt: true,
  approvedAt:  true,
  expiryDate:  true,
  createdAt:   true,
  person: {
    select: {
      id:         true,
      name:       true,
      employeeId: true,
      department: { select: { id: true, name: true } },
    },
  },
  technique: {
    select: {
      id:   true,
      name: true,
      code: true,
      type: true,
    },
  },
  supervisor: {
    select: { id: true, name: true },
  },
  initiatedBy: {
    select: { id: true, name: true },
  },
  signatories: {
    select: {
      id:            true,
      stepOrder:     true,
      requiredRole:  true,
      status:        true,
      signedAt:      true,
      justification: true,
      signedBy:      { select: { id: true, name: true } },
      assignedTo:    { select: { id: true, name: true } },
    },
    orderBy: { stepOrder: 'asc' as const },
  },
  certificate: {
    select: {
      id:         true,
      certNumber: true,
      issuedAt:   true,
      fileUrl:    true,
    },
  },
  _count: { select: { scannedDocuments: true } },
} as const

// ── Shared helper — load a person's roles + department for authz checks ──

async function getAuthzProfile(personId: string) {
  const person = await prisma.person.findUnique({
    where:  { id: personId },
    select: {
      id:         true,
      name:       true,
      roles:      { select: { role: true } },
      department: { select: { code: true } },
    },
  })
  if (!person) throw new Error('Person not found')
  return {
    id:             person.id,
    name:           person.name,
    roles:          person.roles.map((r) => r.role),
    departmentCode: person.department?.code ?? '',
  }
}

// ─────────────────────────────────────────────────────────────────
// TECHNIQUE MANAGEMENT
// ─────────────────────────────────────────────────────────────────

export async function getAllTechniques(filters?: {
  departmentId?: string
  isActive?:     boolean
}) {
  const where: Record<string, unknown> = {}
  if (filters?.departmentId) where.departmentId = filters.departmentId
  if (filters?.isActive !== undefined) where.isActive = filters.isActive

  return prisma.technique.findMany({
    where,
    select:  TECHNIQUE_SELECT,
    orderBy: { name: 'asc' },
  })
}

export async function getTechniqueById(id: string) {
  return prisma.technique.findUnique({
    where:  { id },
    select: TECHNIQUE_SELECT,
  })
}

export async function createTechnique(
  input:         CreateTechniqueInput,
  justification: string,
  actorId:       string
) {
  const parsed = createTechniqueSchema.safeParse(input)
  if (!parsed.success) throw new Error(parsed.error.message)

  const existing = await prisma.technique.findUnique({
    where: { code: input.code },
  })
  if (existing) throw new Error('A technique with this code already exists')

  const technique = await prisma.technique.create({
    data: {
      name:         input.name,
      code:         input.code,
      type:         input.type,
      departmentId: input.departmentId,
    },
  })

  await logAuditEvent({
    userId:        actorId,
    action:        'CREATE',
    module:        'QUALIFICATION',
    recordId:      technique.id,
    recordType:    'Technique',
    beforeValue:   null,
    afterValue:    {
      name: input.name,
      code: input.code,
      type: input.type,
    },
    justification,
  })

  return technique
}

// ─────────────────────────────────────────────────────────────────
// QUALIFICATION RECORD MANAGEMENT
// ─────────────────────────────────────────────────────────────────

export async function getQualifications(filters?: {
  personId?:           string   // qualifications about this person (they are the analyst)
  initiatedById?:      string   // qualifications this person created
  supervisorId?:       string   // qualifications this person supervised
  relevantToId?:       string   // personId OR initiatedById OR supervisorId matches this person
  pendingSignoffForId?: string  // this person is the assigned approver for the current pending step
  techniqueId?:        string
  status?:             string
  subordinateIds?:     string[] // scope to this exact set of analyst IDs (e.g. "my team")
  departmentId?:       string   // org-hierarchy filters — "All data" scope only
  unitId?:             string
  sectionId?:          string
  fromDate?:           string   // 'YYYY-MM-DD' — period filter on initiatedAt, lower bound
  toDate?:             string   // 'YYYY-MM-DD' — period filter on initiatedAt, upper bound
}) {
  // Auto-expire overdue qualifications
  await prisma.qualificationRecord.updateMany({
    where: {
      status:     'APPROVED',
      expiryDate: { lt: new Date() },
    },
    data: { status: 'EXPIRED' },
  })

  const where: Record<string, unknown> = {}

  if (filters?.relevantToId) {
    where.OR = [
      { personId:      filters.relevantToId },
      { initiatedById: filters.relevantToId },
      { supervisorId:  filters.relevantToId },
    ]
  } else if (filters?.personId) {
    where.personId = filters.personId
  } else if (filters?.initiatedById) {
    where.initiatedById = filters.initiatedById
  } else if (filters?.supervisorId) {
    where.supervisorId = filters.supervisorId
  } else if (filters?.subordinateIds !== undefined) {
    // Scope to an exact set of analysts — an empty set means no matches
    where.personId = { in: filters.subordinateIds }
  } else if (filters?.pendingSignoffForId) {
    where.status      = 'IN_PROGRESS'
    where.signatories = { some: { status: 'PENDING', assignedToId: filters.pendingSignoffForId } }
  }

  if (filters?.techniqueId) where.techniqueId = filters.techniqueId
  if (filters?.status)      where.status      = filters.status

  if (filters?.departmentId || filters?.unitId || filters?.sectionId) {
    where.person = {
      ...(filters.departmentId && { departmentId: filters.departmentId }),
      ...(filters.unitId       && { unitId:       filters.unitId       }),
      ...(filters.sectionId    && { sectionId:    filters.sectionId    }),
    }
  }

  if (filters?.fromDate || filters?.toDate) {
    where.initiatedAt = {
      ...(filters.fromDate && { gte: new Date(filters.fromDate) }),
      ...(filters.toDate   && { lte: new Date(`${filters.toDate}T23:59:59.999`) }),
    }
  }

  return prisma.qualificationRecord.findMany({
    where,
    select:  QUALIFICATION_SELECT,
    orderBy: { initiatedAt: 'desc' },
  })
}

export async function getQualificationById(id: string) {
  return prisma.qualificationRecord.findUnique({
    where:  { id },
    select: {
      ...QUALIFICATION_SELECT,
      requalificationOf: true,
      scannedDocuments: {
        select: {
          id:          true,
          fileUrl:     true,
          fileName:    true,
          fileType:    true,
          description: true,
          uploadedAt:  true,
          uploadedBy:  { select: { id: true, name: true } },
        },
        orderBy: { uploadedAt: 'desc' },
      },
    },
  })
}

export async function createQualification(
  input:         CreateQualificationInput,
  justification: string,
  actorId:       string
) {
  const parsed = createQualificationSchema.safeParse(input)
  if (!parsed.success) throw new Error(parsed.error.message)

  const [person, technique] = await Promise.all([
    prisma.person.findUnique({
      where:  { id: input.personId },
      select: { id: true, name: true, isActive: true },
    }),
    prisma.technique.findUnique({
      where:  { id: input.techniqueId },
      select: { id: true, name: true, isActive: true },
    }),
  ])

  if (!person)           throw new Error('Person not found')
  if (!person.isActive)  throw new Error('Person is inactive')
  if (!technique)        throw new Error('Technique not found')
  if (!technique.isActive) throw new Error('Technique is inactive')

  // Check for existing active qualification for same person+technique
  const existing = await prisma.qualificationRecord.findFirst({
    where: {
      personId:    input.personId,
      techniqueId: input.techniqueId,
      status:      { in: ['INITIATED', 'IN_PROGRESS', 'APPROVED'] },
    },
  })
  if (existing) {
    throw new Error(
      `An active qualification record already exists for ${person.name} on ${technique.name}`
    )
  }

  // Create record + signatory chain in transaction
  const qualification = await prisma.$transaction(async (tx) => {
    const qual = await tx.qualificationRecord.create({
      data: {
        personId:      input.personId,
        techniqueId:   input.techniqueId,
        status:        'IN_PROGRESS',
        performedOn:   new Date(input.performedOn),
        supervisorId:  input.supervisorId,
        initiatedById: actorId,
      },
    })

    // Create 2-step signatory chain per SOP:
    // Step 1 — QC department Trainer signs off (observed competency)
    // Step 2 — QA department Trainer gives final approval
    await tx.signatoryEntry.createMany({
      data: [
        {
          qualificationId: qual.id,
          stepOrder:       1,
          requiredRole:    'QC_TRAINER',
          status:          'PENDING',
        },
        {
          qualificationId: qual.id,
          stepOrder:       2,
          requiredRole:    'QA_TRAINER',
          status:          'PENDING',
        },
      ],
    })

    return qual
  })

  await logAuditEvent({
    userId:        actorId,
    action:        'CREATE',
    module:        'QUALIFICATION',
    recordId:      qualification.id,
    recordType:    'QualificationRecord',
    beforeValue:   null,
    afterValue:    {
      personName:    person.name,
      techniqueName: technique.name,
      performedOn:   input.performedOn,
      supervisorId:  input.supervisorId,
    },
    justification,
  })

  return qualification
}

// ── Signatory assignment (choosing the named QC/QA approver) ──────

export async function getEligibleSignatories(departmentCode: 'QC' | 'QA') {
  return prisma.person.findMany({
    where: {
      isActive:   true,
      department: { code: departmentCode },
      roles:      { some: { role: 'TRAINER' } },
    },
    select:  { id: true, name: true, employeeId: true },
    orderBy: { name: 'asc' },
  })
}

// Assigns the step-1 (QC) approver. Step-2 (QA) is assigned inline when
// step 1 is signed — see signQualification's nextAssigneeId handling.
export async function assignSignatory(
  qualificationId: string,
  assigneeId:      string,
  actorId:         string
) {
  const qual = await prisma.qualificationRecord.findUnique({
    where:  { id: qualificationId },
    select: {
      id:         true,
      status:     true,
      person:     { select: { id: true, name: true } },
      technique:  { select: { id: true, name: true } },
      signatories: { orderBy: { stepOrder: 'asc' } },
      _count:      { select: { scannedDocuments: true } },
    },
  })
  if (!qual) throw new Error('Qualification record not found')
  if (qual.status === 'APPROVED') throw new Error('Already fully approved')
  if (qual.status === 'REVOKED')  throw new Error('This qualification has been revoked')
  if (qual._count.scannedDocuments === 0) {
    throw new Error('Upload evidence documents before assigning the QC sign-off approver')
  }

  const actor = await getAuthzProfile(actorId)
  if (!canManageQualifications(actor)) {
    throw new Error('Only the QA department Trainer/Trainee managing this record can assign the sign-off approver')
  }

  const step1 = qual.signatories.find((s) => s.stepOrder === 1)
  if (!step1) throw new Error('Step 1 signatory entry not found')
  if (step1.status !== 'PENDING') {
    throw new Error('Step 1 has already been signed and its approver can no longer be changed')
  }
  if (step1.assignedToId) {
    throw new Error('A QC sign-off approver has already been assigned and cannot be changed')
  }

  const assignee = await getAuthzProfile(assigneeId)
  if (!canSignQcStep(assignee)) {
    throw new Error('The assigned approver must be a QC department Trainer')
  }

  await prisma.$transaction(async (tx) => {
    await tx.signatoryEntry.update({
      where: { id: step1.id },
      data:  {
        assignedToId: assigneeId,
        assignedById: actorId,
        assignedAt:   new Date(),
      },
    })

    await tx.notification.create({
      data: {
        personId: assigneeId,
        type:     'ASSIGNMENT',
        channel:  'IN_APP',
        title:    'Qualification sign-off requested',
        message:  `You have been selected to give QC sign-off for ${qual.person.name}'s qualification on "${qual.technique.name}".`,
      },
    })
  })

  await logAuditEvent({
    userId:      actorId,
    action:      'UPDATE',
    module:      'QUALIFICATION',
    recordId:    qualificationId,
    recordType:  'SignatoryEntry',
    beforeValue: { stepOrder: 1, assignedToId: step1.assignedToId },
    afterValue:  { stepOrder: 1, assignedToId: assigneeId, assignedToName: assignee.name },
    justification: `Assigned ${assignee.name} as QC sign-off approver`,
  })

  return { assignedTo: { id: assignee.id, name: assignee.name } }
}

// ── Sign off a qualification step ─────────────────────────────────

export async function signQualification(
  qualificationId: string,
  justification:   string,
  password:        string,
  actorId:         string,
  nextAssigneeId?: string
) {
  // Get the full qualification with signatories
  const qual = await prisma.qualificationRecord.findUnique({
    where:  { id: qualificationId },
    select: {
      id:     true,
      status: true,
      person: { select: { id: true, name: true } },
      technique: { select: { id: true, name: true } },
      signatories: {
        orderBy: { stepOrder: 'asc' },
      },
      _count: { select: { scannedDocuments: true } },
    },
  })

  if (!qual) throw new Error('Qualification record not found')
  if (qual.status === 'APPROVED') throw new Error('Already fully approved')
  if (qual.status === 'REVOKED')  throw new Error('This qualification has been revoked')

  const actorForAuthz = await getAuthzProfile(actorId)

  const passwordValid = await verifyUserPassword(actorId, password)
  if (!passwordValid) throw new Error('Incorrect password')

  // Find the next pending step
  const nextStep = qual.signatories.find((s) => s.status === 'PENDING')
  if (!nextStep) throw new Error('No pending signature steps remaining')

  if (!nextStep.assignedToId) {
    throw new Error('No approver has been assigned for this step yet')
  }
  if (nextStep.assignedToId !== actorId) {
    throw new Error('You are not the assigned approver for this step')
  }

  // Department + role gating — step 1 is QC-department Trainer,
  // step 2 is the final QA-department Trainer approval
  if (nextStep.stepOrder === 1) {
    if (!canSignQcStep(actorForAuthz)) {
      throw new Error('Only a QC department Trainer can sign step 1')
    }
    if (qual._count.scannedDocuments === 0) {
      throw new Error('Upload evidence documents before requesting QC sign-off')
    }
  } else {
    if (!canSignQaStep(actorForAuthz)) {
      throw new Error('Only a QA department Trainer can sign step 2')
    }
  }

  // Check if this is the final step
  const isLastStep = nextStep.stepOrder === qual.signatories.length
  const willApprove = isLastStep

  // Signing a non-final step requires nominating the approver for the next step
  let nextApprover: Awaited<ReturnType<typeof getAuthzProfile>> | null = null
  if (!willApprove) {
    if (!nextAssigneeId) {
      throw new Error('Select the approver for the next sign-off step')
    }
    nextApprover = await getAuthzProfile(nextAssigneeId)
    if (!canSignQaStep(nextApprover)) {
      throw new Error('The next approver must be a QA department Trainer')
    }
  }

  await prisma.$transaction(async (tx) => {
    // Sign this step
    await tx.signatoryEntry.update({
      where: { id: nextStep.id },
      data:  {
        signedById:    actorId,
        signedAt:      new Date(),
        justification,
        status:        'SIGNED',
      },
    })

    if (willApprove) {
      // Final approval — qualifications carry no expiry
      await tx.qualificationRecord.update({
        where: { id: qualificationId },
        data:  {
          status:     'APPROVED',
          outcome:    'COMPETENT',
          approvedAt: new Date(),
        },
      })

      // Generate certificate
      const certNumber = await generateCertNumber(tx)

      await tx.certificate.create({
        data: {
          certNumber,
          qualificationId,
          personId:   qual.person.id,
          issuedById: actorId,
          fileUrl:    `certificates/${qualificationId}-${certNumber}.pdf`,
          validUntil: null,
        },
      })

      // Notify the analyst
      await tx.notification.create({
        data: {
          personId: qual.person.id,
          type:     'ASSIGNMENT',
          channel:  'IN_APP',
          title:    'Qualification approved',
          message:  `You are now qualified on "${qual.technique.name}". Certificate issued.`,
        },
      })
    } else if (nextApprover) {
      // Nominate the step-2 approver chosen alongside this sign-off
      const step2 = qual.signatories.find((s) => s.stepOrder === nextStep.stepOrder + 1)
      if (step2) {
        await tx.signatoryEntry.update({
          where: { id: step2.id },
          data:  {
            assignedToId: nextApprover.id,
            assignedById: actorId,
            assignedAt:   new Date(),
          },
        })

        await tx.notification.create({
          data: {
            personId: nextApprover.id,
            type:     'ASSIGNMENT',
            channel:  'IN_APP',
            title:    'Qualification sign-off requested',
            message:  `You have been selected to give final QA approval for ${qual.person.name}'s qualification on "${qual.technique.name}".`,
          },
        })
      }
    }
  })

  await logAuditEvent({
    userId:        actorId,
    action:        'APPROVE',
    module:        'QUALIFICATION',
    recordId:      qualificationId,
    recordType:    'QualificationRecord',
    beforeValue:   { stepOrder: nextStep.stepOrder, status: 'PENDING' },
    afterValue:    {
      stepOrder:    nextStep.stepOrder,
      status:       'SIGNED',
      signedBy:     actorForAuthz.name,
      fullyApproved: willApprove,
    },
    justification,
  })

  return { willApprove }
}

// ── Reject a qualification ─────────────────────────────────────────

export async function rejectQualification(
  qualificationId: string,
  justification:   string,
  actorId:         string
) {
  const qual = await prisma.qualificationRecord.findUnique({
    where:  { id: qualificationId },
    select: { id: true, status: true, personId: true, technique: { select: { name: true } } },
  })
  if (!qual) throw new Error('Qualification not found')

  await prisma.$transaction(async (tx) => {
    await tx.qualificationRecord.update({
      where: { id: qualificationId },
      data:  { status: 'REVOKED', outcome: 'NOT_YET_COMPETENT' },
    })

    // Update all pending signatory steps to REJECTED
    await tx.signatoryEntry.updateMany({
      where:  { qualificationId, status: 'PENDING' },
      data:   { status: 'REJECTED' },
    })

    // Notify the analyst
    await tx.notification.create({
      data: {
        personId: qual.personId,
        type:     'FAILED',
        channel:  'IN_APP',
        title:    'Qualification not approved',
        message:  `Your qualification for "${qual.technique.name}" was not approved. Please speak with your Training Coordinator.`,
      },
    })
  })

  await logAuditEvent({
    userId:        actorId,
    action:        'REJECT',
    module:        'QUALIFICATION',
    recordId:      qualificationId,
    recordType:    'QualificationRecord',
    beforeValue:   { status: qual.status },
    afterValue:    { status: 'REVOKED', outcome: 'NOT_YET_COMPETENT' },
    justification,
  })
}

// ── Upload scanned document ────────────────────────────────────────

export async function uploadScannedDocument(
  qualificationId: string,
  fileBuffer:       Buffer,
  fileName:         string,
  fileSize:         number,
  fileType:         string,
  description:      string,
  actorId:          string
) {
  const qual = await prisma.qualificationRecord.findUnique({
    where:  { id: qualificationId },
    select: { id: true, status: true },
  })
  if (!qual) throw new Error('Qualification record not found')
  if (qual.status === 'APPROVED') {
    throw new Error('Cannot upload documents to an approved qualification')
  }

  // Validate file type
  const allowed = ['pdf', 'jpg', 'jpeg', 'png']
  const ext     = fileName.split('.').pop()?.toLowerCase() ?? ''
  if (!allowed.includes(ext)) {
    throw new Error('Only PDF, JPG, and PNG files are allowed')
  }

  // Validate file size — 20MB max for scanned documents
  if (fileSize > 20 * 1024 * 1024) {
    throw new Error('File size exceeds 20MB limit')
  }

  const mimeTypes: Record<string, string> = {
    pdf:  'application/pdf',
    jpg:  'image/jpeg',
    jpeg: 'image/jpeg',
    png:  'image/png',
  }

  const uploadResult = await uploadFile(
    fileBuffer,
    fileName,
    'qualifications',
    mimeTypes[ext] ?? 'application/octet-stream'
  )

  const doc = await prisma.scannedDocument.create({
    data: {
      qualificationId,
      fileUrl:     uploadResult.key,
      fileName,
      fileType:    ext,
      description,
      uploadedById: actorId,
    },
  })

  await logAuditEvent({
    userId:        actorId,
    action:        'UPLOAD',
    module:        'QUALIFICATION',
    recordId:      qualificationId,
    recordType:    'ScannedDocument',
    beforeValue:   null,
    afterValue:    { fileName, description, fileSize },
    justification: `Scanned qualification evidence uploaded: ${description}`,
  })

  return doc
}

// ── Get signed URL for a scanned document ─────────────────────────

export async function getScannedDocumentUrl(docId: string): Promise<string> {
  const doc = await prisma.scannedDocument.findUnique({
    where:  { id: docId },
    select: { fileUrl: true },
  })
  if (!doc) throw new Error('Document not found')
  return getSignedFileUrl(doc.fileUrl, 3600)
}

// ── Get certificate signed URL ────────────────────────────────────

export async function getCertificateUrl(certId: string): Promise<string> {
  const cert = await prisma.certificate.findUnique({
    where:  { id: certId },
    select: { fileUrl: true },
  })
  if (!cert) throw new Error('Certificate not found')
  return getSignedFileUrl(cert.fileUrl, 3600)
}

// ── Get competency matrix ─────────────────────────────────────────

export async function getCompetencyMatrix(filters?: {
  departmentId?:   string
  sectionId?:      string
  subordinateIds?: string[]   // ← new
}) {
  await prisma.qualificationRecord.updateMany({
    where: {
      status:     'APPROVED',
      expiryDate: { lt: new Date() },
    },
    data: { status: 'EXPIRED' },
  })

  const persons = await prisma.person.findMany({
    where: {
      isActive: true,
      // Subordinate scoping takes priority over department/section filters
      ...(filters?.subordinateIds && filters.subordinateIds.length > 0
        ? { id: { in: filters.subordinateIds } }
        : {
            ...(filters?.departmentId && { departmentId: filters.departmentId }),
            ...(filters?.sectionId    && { sectionId:    filters.sectionId    }),
          }
      ),
    },
    select: {
      id:          true,
      name:        true,
      employeeId:  true,
      department:  { select: { name: true } },
      qualificationRecords: {
        select: {
          id:          true,
          status:      true,
          expiryDate:  true,
          techniqueId: true,
        },
      },
    },
    orderBy: { name: 'asc' },
  })

  const techniques = await prisma.technique.findMany({
    where:   { isActive: true },
    select:  { id: true, name: true, code: true },
    orderBy: { name: 'asc' },
  })

  return { persons, techniques }
}

// ── Upcoming expiries (for dashboard alerts) ──────────────────────

export async function getUpcomingExpiries(daysAhead: number = 30) {
  const cutoff = new Date()
  cutoff.setDate(cutoff.getDate() + daysAhead)

  return prisma.qualificationRecord.findMany({
    where: {
      status:     'APPROVED',
      expiryDate: { lte: cutoff, gte: new Date() },
    },
    select: {
      ...QUALIFICATION_SELECT,
    },
    orderBy: { expiryDate: 'asc' },
  })
}

// ── Get persons and techniques for form dropdowns ─────────────────

export async function getPersonsAndTechniques() {
  const [persons, techniques, departments] = await Promise.all([
    prisma.person.findMany({
      where:   { isActive: true },
      select:  { id: true, name: true, employeeId: true, designation: true },
      orderBy: { name: 'asc' },
    }),
    prisma.technique.findMany({
      where:   { isActive: true },
      select:  { id: true, name: true, code: true, type: true },
      orderBy: { name: 'asc' },
    }),
    prisma.department.findMany({
      where:   { isActive: true },
      select:  { id: true, name: true },
      orderBy: { name: 'asc' },
    }),
  ])

  return { persons, techniques, departments }
}

// ── Helper — generate unique certificate number ───────────────────

async function generateCertNumber(
  tx: Omit<typeof prisma, '$connect' | '$disconnect' | '$on' | '$transaction' | '$use' | '$extends'>
): Promise<string> {
  const year  = new Date().getFullYear()
  const count = await tx.certificate.count({
    where: {
      issuedAt: {
        gte: new Date(`${year}-01-01`),
        lte: new Date(`${year}-12-31`),
      },
    },
  })
  const seq = String(count + 1).padStart(5, '0')
  return `CERT-${year}-${seq}`
}
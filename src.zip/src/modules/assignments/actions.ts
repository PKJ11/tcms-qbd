'use server'

import { prisma }        from '@/lib/prisma'
import { logAuditEvent } from '@/modules/audit-trail'
import { createAssignmentSchema } from './schema'
import type { CreateAssignmentInput } from './types'
import { syncRefresherCompletion } from '@/modules/refresher'
import { resolveVersionPins, pinAssignmentMaterialVersions } from './version-pins'
import { scanAndNotifyOverdue } from '@/modules/notifications'

// ── Shared select ─────────────────────────────────────────────────

const ASSIGNMENT_SELECT = {
  id:           true,
  trigger:      true,
  status:       true,
  dueDate:      true,
  startedAt:    true,
  viewedAt:     true,
  completedAt:  true,
  acknowledged: true,
  createdAt:    true,
  person: {
    select: { id: true, name: true, employeeId: true },
  },
  topic: {
    select: { id: true, name: true, trainingType: true },
  },
  assignedBy: {
    select: { id: true, name: true },
  },
  questionBankVersion: {
    select: { versionNo: true, versionLabel: true },
  },
  materialVersions: {
    select: {
      materialId: true,
      materialVersion: { select: { versionNo: true, versionLabel: true } },
    },
  },
} as const

// ── Helper — recompute overdue status + notify ─────────────────────
// Runs on every assignments read so overdue flagging and notifications
// (trainee + trainer + manager for overdue, trainee-only for due-soon)
// happen automatically — no external cron or manual scan required.

async function refreshOverdueStatuses() {
  await prisma.trainingAssignment.updateMany({
    where: {
      status: { in: ['NOT_STARTED', 'IN_PROGRESS'] },
      dueDate: { lt: new Date() },
    },
    data: { status: 'OVERDUE' },
  })

  try {
    await scanAndNotifyOverdue()
  } catch (error) {
    // Notification failures must not block assignment reads
    console.error('[OVERDUE NOTIFY ERROR]', error)
  }
}

// ── Get all assignments (admin view) ──────────────────────────────

export async function getAssignments(filters?: {
  personId?:     string
  topicId?:      string
  status?:       string
  trigger?:      string
  departmentId?: string
  unitId?:       string
  sectionId?:    string
  managerId?:    string   // ← filters to this manager's direct reports
  assignedById?: string   // ← filters to trainings a specific trainer assigned
}) {
  await refreshOverdueStatuses()

  const where: Record<string, unknown> = {}

  if (filters?.personId)     where.personId     = filters.personId
  if (filters?.topicId)      where.topicId       = filters.topicId
  if (filters?.status)       where.status        = filters.status
  if (filters?.trigger)      where.trigger        = filters.trigger
  if (filters?.assignedById) where.assignedById   = filters.assignedById

  // Manager scope combines with department/unit/section — e.g. "my team, in dept X"
  if (filters?.managerId || filters?.departmentId || filters?.unitId || filters?.sectionId) {
    where.person = {
      ...(filters?.managerId    && { managerId:    filters.managerId    }),
      ...(filters?.departmentId && { departmentId: filters.departmentId }),
      ...(filters?.unitId       && { unitId:       filters.unitId       }),
      ...(filters?.sectionId    && { sectionId:    filters.sectionId    }),
    }
  }

  return prisma.trainingAssignment.findMany({
    where,
    select:  ASSIGNMENT_SELECT,
    orderBy: { dueDate: 'asc' },
  })
}

// ── Get assignments for current user ──────────────────────────────

export async function getMyAssignments(personId: string) {
  await refreshOverdueStatuses()

  return prisma.trainingAssignment.findMany({
    where:  { personId },
    select: {
      ...ASSIGNMENT_SELECT,
      topic: {
        select: {
          id:           true,
          name:         true,
          description:  true,
          trainingType: true,
          materials: {
            where:  { status: 'APPROVED' },
            select: {
              id:             true,
              title:          true,
              currentVersion: true,
              versions: {
                where:   { status: 'APPROVED' },
                orderBy: { versionNo: 'desc' },
                take:    1,
                select: {
                  id:           true,
                  versionLabel: true,
                  fileType:     true,
                  status:       true,
                },
              },
            },
          },
        },
      },
    },
    orderBy: { dueDate: 'asc' },
  })
}

// ── Get single assignment ─────────────────────────────────────────

export async function getAssignmentById(id: string) {
  return prisma.trainingAssignment.findUnique({
    where:  { id },
    select: {
      ...ASSIGNMENT_SELECT,
      topic: {
        select: {
          id:           true,
          name:         true,
          description:  true,
          trainingType: true,
          materials: {
            where:  { status: 'APPROVED' },
            select: {
              id:             true,
              title:          true,
              currentVersion: true,
              versions: {
                where:   { status: 'APPROVED' },
                orderBy: { versionNo: 'desc' },
                take:    1,
                select: {
                  id:           true,
                  versionLabel: true,
                  fileType:     true,
                  fileUrl:      true,
                  status:       true,
                },
              },
            },
          },
        },
      },
      materialConfirmations: {
        select: { materialId: true, confirmedAt: true },
      },
    },
  })
}

// ── Create assignment(s) — individual or bulk ──────────────────────

export async function createAssignments(
  input:         CreateAssignmentInput,
  justification: string,
  actorId:       string
) {
  const parsed = createAssignmentSchema.safeParse(input)
  if (!parsed.success) {
    throw new Error(parsed.error.message)
  }

  // Verify topic exists and is active
  const topic = await prisma.trainingTopic.findUnique({
    where:  { id: input.topicId },
    select: { id: true, name: true, isActive: true },
  })
  if (!topic)            throw new Error('Topic not found')
  if (!topic.isActive)   throw new Error('Topic is inactive')

  // Verify persons exist — a trainer can never assign training to themselves
  const persons = await prisma.person.findMany({
    where:  { id: { in: input.personIds }, isActive: true, NOT: { id: actorId } },
    select: { id: true, name: true },
  })
  if (persons.length === 0) {
    throw new Error('No valid active persons found')
  }

  // Check for existing incomplete assignments for the same topic AND the
  // same trigger, made by THIS trainer. The trigger match matters: an
  // induction assignment of a topic and a scheduled (or refresher)
  // assignment of the same topic are separate obligations — the person
  // must do each one — so an active INDUCTION assignment must never block
  // a new SCHEDULE assignment of that topic (and vice versa). Other
  // trainers may also independently assign the same topic+trigger.
  const existing = await prisma.trainingAssignment.findMany({
    where: {
      personId:     { in: persons.map((p) => p.id) },
      topicId:      input.topicId,
      trigger:      input.trigger,
      assignedById: actorId,
      status:       { in: ['NOT_STARTED', 'IN_PROGRESS', 'OVERDUE'] },
    },
    select: { personId: true },
  })
  const existingPersonIds = new Set(existing.map((e) => e.personId))
  const newPersons = persons.filter((p) => !existingPersonIds.has(p.id))

  const triggerLabel: Record<string, string> = {
    INDUCTION:        'induction',
    SCHEDULE:         'scheduled',
    REFRESHER:        'refresher',
    SOP_SELF_READOUT: 'SOP self-readout',
  }
  const tLabel = triggerLabel[input.trigger] ?? input.trigger.toLowerCase()

  // Notify the assigning trainer if any selected persons were skipped because
  // this topic is already due for them under the SAME trigger — fires even
  // when everyone was skipped
  if (existingPersonIds.size > 0) {
    const skippedNames = persons
      .filter((p) => existingPersonIds.has(p.id))
      .map((p) => p.name)

    await prisma.notification.create({
      data: {
        personId: actorId,
        type:     'ASSIGNMENT',
        channel:  'IN_APP',
        title:    `"${topic.name}" ${tLabel} training already due for some people`,
        message:  `${skippedNames.length} of the selected people already have an active ${tLabel} assignment for "${topic.name}" and were skipped: ${skippedNames.join(', ')}.`,
      },
    })
  }

  if (newPersons.length === 0) {
    throw new Error(`All selected persons already have an active ${tLabel} assignment for this topic`)
  }

  // Pin the question-bank/material versions that are live right now, so this
  // batch of assignments always knows exactly what it was assigned against.
  const pins = await resolveVersionPins(prisma, input.topicId)
  const batchStartedAt = new Date()

  // Create assignments
  const created = await prisma.$transaction(async (tx) => {
    const result = await tx.trainingAssignment.createMany({
      data: newPersons.map((p) => ({
        personId:              p.id,
        topicId:               input.topicId,
        trigger:               input.trigger,
        status:                'NOT_STARTED' as const,
        assignedById:          actorId,
        dueDate:               new Date(input.dueDate),
        needIdentifiedById:    input.needIdentifiedById?.trim() || null,
        needBasis:             input.needBasis?.trim() || null,
        questionBankVersionId: pins.questionBankVersionId,
      })),
    })

    if (pins.materialPins.length > 0) {
      const createdAssignments = await tx.trainingAssignment.findMany({
        where: {
          personId:     { in: newPersons.map((p) => p.id) },
          topicId:      input.topicId,
          assignedById: actorId,
          createdAt:    { gte: batchStartedAt },
        },
        select: { id: true },
      })
      await pinAssignmentMaterialVersions(tx, createdAssignments.map((a) => a.id), pins.materialPins)
    }

    return result
  })

  // Create notifications
  await prisma.notification.createMany({
    data: newPersons.map((p) => ({
      personId: p.id,
      type:     'ASSIGNMENT' as const,
      channel:  'IN_APP'      as const,
      title:    'New training assigned',
      message:  `You have been assigned "${topic.name}" training. Due by ${new Date(input.dueDate).toLocaleDateString('en-IN')}.`,
    })),
  })

  // Audit log
  await logAuditEvent({
    userId:        actorId,
    action:        'ASSIGN',
    module:        'TRAINING_ASSIGNMENT',
    recordId:      input.topicId,
    recordType:    'TrainingTopic',
    beforeValue:   null,
    afterValue:    {
      topicName:  topic.name,
      personIds:  newPersons.map((p) => p.id),
      personNames: newPersons.map((p) => p.name),
      trigger:    input.trigger,
      dueDate:    input.dueDate,
    },
    justification,
  })

  return {
    created: created.count,
    skipped: existingPersonIds.size,
    skippedNames: persons
      .filter((p) => existingPersonIds.has(p.id))
      .map((p) => p.name),
  }
}

// ── Find topics whose compulsory scope covers a given placement ────
// A scope row matches when its department matches and (its unit is unset
// or matches) and (its section is unset or matches). Department-only scope
// rows apply to everyone in the department; unit/section rows narrow it further.

export async function getScopedTopics(
  departmentId: string,
  unitId:       string,
  sectionId?:   string
) {
  const sectionCond = sectionId
    ? { OR: [{ sectionId: null }, { sectionId }] }
    : { sectionId: null }

  return prisma.trainingTopic.findMany({
    where: {
      isActive: true,
      topicScopes: {
        some: {
          departmentId,
          AND: [
            { OR: [{ unitId: null }, { unitId }] },
            sectionCond,
          ],
        },
      },
    },
    select: { id: true, name: true },
  })
}

// ── Auto-assign induction training on person creation ─────────────
// Called from personnel/actions.ts when a new person is created

export async function autoAssignInductionTraining(
  personId:     string,
  departmentId: string,
  unitId:       string,
  actorId:      string,
  sectionId?:   string
) {
  const topics = await getScopedTopics(departmentId, unitId, sectionId)

  if (topics.length === 0) return []

  const dueDate = new Date()
  dueDate.setDate(dueDate.getDate() + 14) // 14 days for induction

  const batchStartedAt = new Date()

  await prisma.$transaction(async (tx) => {
    // Each topic can have its own question bank/material versions, so pins
    // are resolved per topic rather than once for the whole induction batch.
    const topicPins = await Promise.all(
      topics.map(async (t) => ({ topicId: t.id, pins: await resolveVersionPins(tx, t.id) }))
    )

    await tx.trainingAssignment.createMany({
      data: topics.map((t) => ({
        personId,
        topicId:               t.id,
        trigger:               'INDUCTION' as const,
        status:                'NOT_STARTED' as const,
        assignedById:          actorId,
        dueDate,
        questionBankVersionId: topicPins.find((tp) => tp.topicId === t.id)!.pins.questionBankVersionId,
      })),
    })

    const createdAssignments = await tx.trainingAssignment.findMany({
      where: {
        personId,
        topicId:   { in: topics.map((t) => t.id) },
        trigger:   'INDUCTION',
        createdAt: { gte: batchStartedAt },
      },
      select: { id: true, topicId: true },
    })

    for (const a of createdAssignments) {
      const tp = topicPins.find((x) => x.topicId === a.topicId)
      if (tp && tp.pins.materialPins.length > 0) {
        await pinAssignmentMaterialVersions(tx, [a.id], tp.pins.materialPins)
      }
    }
  })

  await prisma.notification.createMany({
    data: topics.map((t) => ({
      personId,
      type:    'ASSIGNMENT' as const,
      channel: 'IN_APP'      as const,
      title:   'Induction training assigned',
      message: `"${t.name}" has been assigned as part of your induction.`,
    })),
  })

  await logAuditEvent({
    userId:        actorId,
    action:        'ASSIGN',
    module:        'TRAINING_ASSIGNMENT',
    recordId:      personId,
    recordType:    'Person',
    beforeValue:   null,
    afterValue:    {
      topics:  topics.map((t) => t.name),
      trigger: 'INDUCTION',
    },
    justification: 'Auto-assigned induction training based on department on person creation',
  })

  return topics.map((t) => t.id)
}

// ── Auto-assign trainer-curated Topic Group induction training ─────
// Called from personnel/actions.ts alongside autoAssignInductionTraining.
// A Topic Group is scoped one of three ways: department-wide (no unit),
// whole-unit, or one section of a unit. They stack for a new joinee:
//   - the department-wide group applies to everyone in the department;
//   - the whole-unit group applies to everyone in that unit;
//   - a section group additionally applies only to that section.
// So a person in QA / Unit 2 / LCMS gets department-wide + Unit 2 + LCMS
// topics, deduped. Due `joiningDate + 1 month` — distinct from the 14-day
// due date used for TopicScope-driven induction above. excludeTopicIds
// skips topics already assigned by that call, so a topic in both a
// TopicScope and a TopicGroup doesn't create two induction assignments.

export async function autoAssignTopicGroupInduction(
  personId:         string,
  departmentId:     string,
  unitId:           string,
  actorId:          string,
  joiningDate?:     Date | null,
  sectionId?:       string | null,
  excludeTopicIds:  string[] = []
) {
  // department-wide, plus whole-unit and this-section for the person's own unit
  const scopeConds: { unitId: string | null; sectionId: string | null }[] = [
    { unitId: null, sectionId: null },
  ]
  if (unitId) {
    scopeConds.push({ unitId, sectionId: null })
    if (sectionId) scopeConds.push({ unitId, sectionId })
  }

  const groups = await prisma.topicGroup.findMany({
    where: { departmentId, isActive: true, OR: scopeConds },
    select: {
      createdById: true,
      items: {
        select: { topic: { select: { id: true, name: true, isActive: true } } },
      },
    },
  })

  // assignedById is the trainer who curated the group the topic came from —
  // not whoever happened to be creating the new person's account — so
  // "Assigned by" on the assignment correctly credits the trainer.
  const seen   = new Set(excludeTopicIds)
  const topics: { id: string; name: string; assignedById: string }[] = []
  for (const group of groups) {
    for (const item of group.items) {
      if (!item.topic.isActive || seen.has(item.topic.id)) continue
      seen.add(item.topic.id)
      topics.push({ id: item.topic.id, name: item.topic.name, assignedById: group.createdById })
    }
  }

  if (topics.length === 0) return []

  const dueDate = joiningDate ? new Date(joiningDate) : new Date()
  dueDate.setMonth(dueDate.getMonth() + 1) // joining date + 1 month

  const batchStartedAt = new Date()

  await prisma.$transaction(async (tx) => {
    const topicPins = await Promise.all(
      topics.map(async (t) => ({ topicId: t.id, pins: await resolveVersionPins(tx, t.id) }))
    )

    await tx.trainingAssignment.createMany({
      data: topics.map((t) => ({
        personId,
        topicId:               t.id,
        trigger:               'INDUCTION' as const,
        status:                'NOT_STARTED' as const,
        assignedById:          t.assignedById,
        dueDate,
        questionBankVersionId: topicPins.find((tp) => tp.topicId === t.id)!.pins.questionBankVersionId,
      })),
    })

    const createdAssignments = await tx.trainingAssignment.findMany({
      where: {
        personId,
        topicId:   { in: topics.map((t) => t.id) },
        trigger:   'INDUCTION',
        createdAt: { gte: batchStartedAt },
      },
      select: { id: true, topicId: true },
    })

    for (const a of createdAssignments) {
      const tp = topicPins.find((x) => x.topicId === a.topicId)
      if (tp && tp.pins.materialPins.length > 0) {
        await pinAssignmentMaterialVersions(tx, [a.id], tp.pins.materialPins)
      }
    }
  })

  await prisma.notification.createMany({
    data: topics.map((t) => ({
      personId,
      type:    'ASSIGNMENT' as const,
      channel: 'IN_APP'      as const,
      title:   'Induction training assigned',
      message: `"${t.name}" has been assigned as part of your department's induction topic group. Due ${dueDate.toLocaleDateString('en-IN')}.`,
    })),
  })

  await logAuditEvent({
    userId:        actorId,
    action:        'ASSIGN',
    module:        'TRAINING_ASSIGNMENT',
    recordId:      personId,
    recordType:    'Person',
    beforeValue:   null,
    afterValue:    {
      topics:  topics.map((t) => t.name),
      trigger: 'INDUCTION',
      source:  'TopicGroup',
      dueDate,
    },
    justification: "Auto-assigned induction training from the department's topic group(s) on person creation",
  })

  return topics.map((t) => t.id)
}

// ── Preview fixed trainings for a department/unit/section transfer ─
// Called from the personnel edit flow when an admin is about to move a
// person into a new department/unit/section, so they can decide which of
// that placement's fixed trainings to (re-)assign.

export async function getScopedTrainingsForTransfer(
  personId:     string,
  departmentId: string,
  unitId:       string,
  sectionId?:   string
) {
  const topics = await getScopedTopics(departmentId, unitId, sectionId)
  if (topics.length === 0) return []

  const ACTIVE_STATUSES = ['NOT_STARTED', 'IN_PROGRESS', 'OVERDUE']

  return Promise.all(
    topics.map(async (t) => {
      const lastAssignment = await prisma.trainingAssignment.findFirst({
        where:   { personId, topicId: t.id },
        orderBy: { createdAt: 'desc' },
        select:  { status: true, trigger: true, dueDate: true, completedAt: true, createdAt: true },
      })

      const badge: 'completed' | 'active' | null =
        !lastAssignment ? null :
        lastAssignment.status === 'COMPLETED' ? 'completed' :
        ACTIVE_STATUSES.includes(lastAssignment.status) ? 'active' :
        null

      return {
        topicId:       t.id,
        name:          t.name,
        defaultChecked: badge === null,
        badge,
        lastAssignment,
      }
    })
  )
}

// ── Assign the fixed trainings an admin picked for a person's new scope ──
// Called after a person's department/unit/section has been updated.

export async function assignScopedTrainingsOnTransfer(
  personId:      string,
  topicIds:      string[],
  dueDate:       string,
  actorId:       string,
  justification: string
) {
  if (topicIds.length === 0) throw new Error('No trainings selected')

  const topics = await prisma.trainingTopic.findMany({
    where:  { id: { in: topicIds }, isActive: true },
    select: { id: true, name: true },
  })
  if (topics.length === 0) throw new Error('No valid active topics found')

  // Safety net against double-submits — skip any topic that already has an
  // active assignment for this person, regardless of who assigned it.
  const existing = await prisma.trainingAssignment.findMany({
    where: {
      personId,
      topicId: { in: topics.map((t) => t.id) },
      status:  { in: ['NOT_STARTED', 'IN_PROGRESS', 'OVERDUE'] },
    },
    select: { topicId: true },
  })
  const existingTopicIds = new Set(existing.map((e) => e.topicId))
  const newTopics = topics.filter((t) => !existingTopicIds.has(t.id))

  if (newTopics.length === 0) {
    return { created: 0, skipped: topics.length, skippedNames: topics.map((t) => t.name) }
  }

  const dueDateObj = new Date(dueDate)
  const batchStartedAt = new Date()

  await prisma.$transaction(async (tx) => {
    const topicPins = await Promise.all(
      newTopics.map(async (t) => ({ topicId: t.id, pins: await resolveVersionPins(tx, t.id) }))
    )

    await tx.trainingAssignment.createMany({
      data: newTopics.map((t) => ({
        personId,
        topicId:               t.id,
        trigger:               'INDUCTION' as const,
        status:                'NOT_STARTED' as const,
        assignedById:          actorId,
        dueDate:                dueDateObj,
        questionBankVersionId: topicPins.find((tp) => tp.topicId === t.id)!.pins.questionBankVersionId,
      })),
    })

    const createdAssignments = await tx.trainingAssignment.findMany({
      where: {
        personId,
        topicId:   { in: newTopics.map((t) => t.id) },
        trigger:   'INDUCTION',
        createdAt: { gte: batchStartedAt },
      },
      select: { id: true, topicId: true },
    })

    for (const a of createdAssignments) {
      const tp = topicPins.find((x) => x.topicId === a.topicId)
      if (tp && tp.pins.materialPins.length > 0) {
        await pinAssignmentMaterialVersions(tx, [a.id], tp.pins.materialPins)
      }
    }
  })

  await prisma.notification.createMany({
    data: newTopics.map((t) => ({
      personId,
      type:    'ASSIGNMENT' as const,
      channel: 'IN_APP'      as const,
      title:   'New training assigned',
      message: `"${t.name}" has been assigned following your department/unit/section change.`,
    })),
  })

  await logAuditEvent({
    userId:        actorId,
    action:        'ASSIGN',
    module:        'TRAINING_ASSIGNMENT',
    recordId:      personId,
    recordType:    'Person',
    beforeValue:   null,
    afterValue:    {
      topics:  newTopics.map((t) => t.name),
      trigger: 'INDUCTION',
      dueDate,
    },
    justification,
  })

  return {
    created: newTopics.length,
    skipped: existingTopicIds.size,
    skippedNames: topics.filter((t) => existingTopicIds.has(t.id)).map((t) => t.name),
  }
}

// ── Revert (cancel) a mistakenly assigned training ─────────────────
// Only allowed while the trainee hasn't started it yet, so no progress
// (material confirmations, assessment attempts) is ever discarded.

export async function revertAssignment(
  assignmentId:  string,
  justification: string,
  actorId:       string
) {
  const assignment = await prisma.trainingAssignment.findUnique({
    where:  { id: assignmentId },
    select: {
      id:       true,
      personId: true,
      status:   true,
      topic:    { select: { name: true } },
    },
  })

  if (!assignment) throw new Error('Assignment not found')
  if (assignment.status !== 'NOT_STARTED') {
    throw new Error('Only assignments that have not been started yet can be reverted')
  }

  await prisma.trainingAssignment.update({
    where: { id: assignmentId },
    data:  { status: 'CANCELLED' },
  })

  await prisma.notification.create({
    data: {
      personId: assignment.personId,
      type:     'ASSIGNMENT_WITHDRAWN',
      channel:  'IN_APP',
      title:    'Training assignment withdrawn',
      message:  `This training assignment was withdrawn: "${assignment.topic.name}".`,
    },
  })

  await logAuditEvent({
    userId:        actorId,
    action:        'REVOKE',
    module:        'TRAINING_ASSIGNMENT',
    recordId:      assignmentId,
    recordType:    'TrainingAssignment',
    beforeValue:   { status: 'NOT_STARTED' },
    afterValue:    { status: 'CANCELLED'   },
    justification,
  })
}

// ── Bulk revert — same NOT_STARTED-only rule, batched over a filtered set ──

export async function revertAssignments(
  assignmentIds: string[],
  justification: string,
  actorId:       string
) {
  if (assignmentIds.length === 0) throw new Error('No assignments selected')

  const assignments = await prisma.trainingAssignment.findMany({
    where:  { id: { in: assignmentIds } },
    select: {
      id:       true,
      personId: true,
      status:   true,
      topic:    { select: { name: true } },
      person:   { select: { name: true } },
    },
  })

  const eligible = assignments.filter((a) => a.status === 'NOT_STARTED')
  const skipped  = assignments
    .filter((a) => a.status !== 'NOT_STARTED')
    .map((a) => ({ id: a.id, personName: a.person.name, topicName: a.topic.name, status: a.status }))

  if (eligible.length > 0) {
    await prisma.trainingAssignment.updateMany({
      where: { id: { in: eligible.map((a) => a.id) } },
      data:  { status: 'CANCELLED' },
    })

    await prisma.notification.createMany({
      data: eligible.map((a) => ({
        personId: a.personId,
        type:     'ASSIGNMENT_WITHDRAWN' as const,
        channel:  'IN_APP' as const,
        title:    'Training assignment withdrawn',
        message:  `This training assignment was withdrawn: "${a.topic.name}".`,
      })),
    })

    for (const a of eligible) {
      await logAuditEvent({
        userId:        actorId,
        action:        'REVOKE',
        module:        'TRAINING_ASSIGNMENT',
        recordId:      a.id,
        recordType:    'TrainingAssignment',
        beforeValue:   { status: 'NOT_STARTED' },
        afterValue:    { status: 'CANCELLED'   },
        justification,
      })
    }
  }

  return { reverted: eligible.length, skipped }
}

// ── Start assignment (user begins viewing material) ────────────────

export async function startAssignment(
  assignmentId: string,
  actorId:      string
) {
  const assignment = await prisma.trainingAssignment.findUnique({
    where:  { id: assignmentId },
    select: { id: true, personId: true, status: true },
  })

  if (!assignment)                  throw new Error('Assignment not found')
  if (assignment.personId !== actorId) throw new Error('Not authorised')
  if (assignment.status !== 'NOT_STARTED') return assignment // already started

  await prisma.trainingAssignment.update({
    where: { id: assignmentId },
    data:  {
      status:    'IN_PROGRESS',
      startedAt: new Date(),
    },
  })

  await logAuditEvent({
    userId:        actorId,
    action:        'UPDATE',
    module:        'TRAINING_ASSIGNMENT',
    recordId:      assignmentId,
    recordType:    'TrainingAssignment',
    beforeValue:   { status: 'NOT_STARTED' },
    afterValue:    { status: 'IN_PROGRESS' },
    justification: 'User started viewing assigned training material',
  })
}

// ── Acknowledge (read & understood) — completes Acknowledgement-Only topics ──

export async function acknowledgeAssignment(
  assignmentId: string,
  actorId:      string
) {
  const assignment = await prisma.trainingAssignment.findUnique({
    where:  { id: assignmentId },
    select: {
      id: true, personId: true, status: true, topicId: true, trigger: true, acknowledged: true,
      topic: { select: { trainingType: true } },
    },
  })

  if (!assignment)                     throw new Error('Assignment not found')
  if (assignment.personId !== actorId) throw new Error('Not authorised')

  // Already acknowledged — nothing changes, so don't touch the record or
  // write a second "training completed" entry to the audit trail.
  if (assignment.acknowledged) {
    return { completed: assignment.status === 'COMPLETED' }
  }

  // Only Acknowledgement-Only topics complete on the ack button itself —
  // Material-Only completes on view, Material+MCQ completes on passing the assessment.
  const willComplete = assignment.topic.trainingType === 'ACKNOWLEDGEMENT_ONLY'

  await prisma.trainingAssignment.update({
    where: { id: assignmentId },
    data:  {
      acknowledged: true,
      ...(willComplete && {
        status:      'COMPLETED',
        completedAt: new Date(),
      }),
    },
  })

  // Sync linked refresher trigger if this was a refresher assignment
  if (willComplete && assignment.trigger === 'REFRESHER') {
    await syncRefresherCompletion(assignment.personId, assignment.topicId)
  }

  await logAuditEvent({
    userId:        actorId,
    action:        'UPDATE',
    module:        'TRAINING_ASSIGNMENT',
    recordId:      assignmentId,
    recordType:    'TrainingAssignment',
    beforeValue:   { acknowledged: false },
    afterValue:    {
      acknowledged: true,
      completed:    willComplete,
    },
    justification: willComplete
      ? 'Training completed — user acknowledged reading and understanding the training material'
      : 'User acknowledged reading and understanding the training material',
  })

  return { completed: willComplete }
}

// ── Mark material viewed — completes Material-Only topics ──────────

export async function markAssignmentViewed(
  assignmentId: string,
  actorId:      string
) {
  const assignment = await prisma.trainingAssignment.findUnique({
    where:  { id: assignmentId },
    select: {
      id: true, personId: true, status: true, viewedAt: true,
    },
  })

  if (!assignment)                     throw new Error('Assignment not found')
  if (assignment.personId !== actorId) throw new Error('Not authorised')

  await prisma.trainingAssignment.update({
    where: { id: assignmentId },
    data: {
      ...(assignment.viewedAt ? {} : { viewedAt: new Date() }),
      ...(assignment.status === 'NOT_STARTED' && {
        status:    'IN_PROGRESS',
        startedAt: new Date(),
      }),
    },
  })

  if (!assignment.viewedAt) {
    await logAuditEvent({
      userId:        actorId,
      action:        'UPDATE',
      module:        'TRAINING_ASSIGNMENT',
      recordId:      assignmentId,
      recordType:    'TrainingAssignment',
      beforeValue:   { viewedAt: null },
      afterValue:    { viewedAt: new Date().toISOString() },
      justification: 'User opened the training material',
    })
  }

  return { completed: false }
}

// ── Confirm a single material — completes Material-Only topics once ──
// every approved material for the topic has been confirmed ────────────

export async function confirmAssignmentMaterial(
  assignmentId: string,
  materialId:   string,
  actorId:      string
) {
  const assignment = await prisma.trainingAssignment.findUnique({
    where:  { id: assignmentId },
    select: {
      id: true, personId: true, status: true, topicId: true, trigger: true,
      topic: {
        select: {
          trainingType: true,
          materials: {
            where:  { status: 'APPROVED' },
            select: { id: true },
          },
        },
      },
    },
  })

  if (!assignment)                     throw new Error('Assignment not found')
  if (assignment.personId !== actorId) throw new Error('Not authorised')

  await prisma.assignmentMaterialConfirmation.upsert({
    where:  { assignmentId_materialId: { assignmentId, materialId } },
    create: { assignmentId, materialId },
    update: {},
  })

  if (assignment.status === 'NOT_STARTED') {
    await prisma.trainingAssignment.update({
      where: { id: assignmentId },
      data:  { status: 'IN_PROGRESS', startedAt: new Date() },
    })
  }

  let allConfirmed = false
  let completed     = false

  if (assignment.topic.trainingType === 'MATERIAL_ONLY') {
    const confirmedCount = await prisma.assignmentMaterialConfirmation.count({
      where: { assignmentId },
    })
    allConfirmed = confirmedCount >= assignment.topic.materials.length

    if (allConfirmed && assignment.status !== 'COMPLETED') {
      completed = true
      await prisma.trainingAssignment.update({
        where: { id: assignmentId },
        data:  { status: 'COMPLETED', completedAt: new Date() },
      })

      if (assignment.trigger === 'REFRESHER') {
        await syncRefresherCompletion(assignment.personId, assignment.topicId)
      }

      await logAuditEvent({
        userId:        actorId,
        action:        'UPDATE',
        module:        'TRAINING_ASSIGNMENT',
        recordId:      assignmentId,
        recordType:    'TrainingAssignment',
        beforeValue:   { status: assignment.status },
        afterValue:    { status: 'COMPLETED' },
        justification: 'Training completed — user confirmed all training material as reviewed',
      })
    }
  } else {
    const confirmedCount = await prisma.assignmentMaterialConfirmation.count({
      where: { assignmentId },
    })
    allConfirmed = confirmedCount >= assignment.topic.materials.length
  }

  return { completed, allConfirmed }
}

// ── Get active topics for assignment ───────────────────────────────

export async function getActiveTopicsForAssignment() {
  return prisma.trainingTopic.findMany({
    where:   { isActive: true },
    select:  { id: true, name: true },
    orderBy: { name: 'asc' },
  })
}

// ── Check if a person has any direct reports ──────────────────────

export async function personHasSubordinates(personId: string): Promise<boolean> {
  const count = await prisma.person.count({
    where: { managerId: personId, isActive: true },
  })
  return count > 0
}